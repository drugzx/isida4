4th version of iSida bot
======

What's new?
* AI parser for messages!
* Developer tools are included.

More info:
* Official [site](http://isida.dsy.name) 
* Information about Installation or Update at [WIKI](http://isida.dsy.name/wiki)
* Xmpp conference: isida@conference.jabber.ru

------

Copyright 2oo9..2o15 by [diSabler](http://dsy.name) under [GPLv3](http://www.gnu.org/licenses/gpl.txt) Licence
